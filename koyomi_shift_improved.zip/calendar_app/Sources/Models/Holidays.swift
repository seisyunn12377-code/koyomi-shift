import Foundation

/// 日本の祝日 (2026年分を収録)。キーは "yyyy-M-d" 形式。
enum Holidays {
    static let names: [String: String] = [
        "2026-1-1": "元日",
        "2026-1-12": "成人の日",
        "2026-2-11": "建国記念の日",
        "2026-2-23": "天皇誕生日",
        "2026-3-20": "春分の日",
        "2026-4-29": "昭和の日",
        "2026-5-3": "憲法記念日",
        "2026-5-4": "みどりの日",
        "2026-5-5": "こどもの日",
        "2026-5-6": "振替休日",
        "2026-7-20": "海の日",
        "2026-8-11": "山の日",
        "2026-9-21": "敬老の日",
        "2026-9-22": "国民の休日",
        "2026-9-23": "秋分の日",
        "2026-10-12": "スポーツの日",
        "2026-11-3": "文化の日",
        "2026-11-23": "勤労感謝の日",
    ]

    static func name(for date: Date) -> String? {
        let cal = Calendar.current
        let y = cal.component(.year, from: date)
        let m = cal.component(.month, from: date)
        let d = cal.component(.day, from: date)
        return names["\(y)-\(m)-\(d)"]
    }

    static func isHoliday(_ date: Date) -> Bool {
        name(for: date) != nil
    }
}
